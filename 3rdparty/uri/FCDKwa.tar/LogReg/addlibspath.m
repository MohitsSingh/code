addpath('/home/uripatis/Workspace/Libs/general');
addpath(genpath('/home/uripatis/Workspace/Libs/MarkSchmidt/'));

addpath('/home/uripatis/Workspace/Data/MatFiles');

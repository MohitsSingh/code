action_roi_dir = '~/storage/action_rois';

% d = dir(fullf
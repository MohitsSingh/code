for t = 31:10:length(fra_db)
    t
    if ~(fra_db(t).isTrain)
        I = imdb.images_data{t};
        curFaceBox = face_boxes(t,:);
        curHandBox = hand_boxes(t,:);
        % if there's not hand there must be an object
        if isnan(curHandBox(1)) && fra_db(t).isTrain
            curHandBox = obj_boxes(t,:);
        end
        if isnan(curFaceBox)
            if ~fra_db(t).isTrain
                faceAndHandPolygon = box2Pts(fra_db(t).I_rect);
                %             action_object_regions{t} = maskedPatch(I,poly2mask2(faceAndHandPolygon,size2(I)),true);
                continue
            else
                error('nan face box in training set!');
            end
        end
        
        faceAndHandPolygon=[box2Pts(curFaceBox);box2Pts(curHandBox)];
        K = convhull(faceAndHandPolygon);
        faceAndHandPolygon = poly2cw2(faceAndHandPolygon(K,:));
        
        q = imgInds==t;
        curTrainingData = training_data(q);
        curScores = cat(2,curTrainingData.test_scores);
        curBoxes =  cat(1,curTrainingData.bbox);
        
        boxPolys = boxes2Polygons(curBoxes);
        boxPolys = cellfun2(@poly2cw2,boxPolys);
        intAreas = zeros(length(boxPolys),1);
                        
        %         continue
        for iPoly = 1:length(boxPolys)
            %             curIntersection = polybool2('&', boxPolys{iPoly},faceAndHandPolygon);
            intAreas(iPoly) = polyarea2(polybool2('&', boxPolys{iPoly},faceAndHandPolygon));
        end
        
        boxScores = curScores(3,:);
        boxScores(intAreas < .5) = -1000;
        
        curMask = poly2mask2(faceAndHandPolygon,size2(I));        
        S = max(LL.scores_fine{t}(:,:,4:end),[],3).*curMask;
        B = zeros(size2(I));
        bc = round(boxCenters(curFaceBox));
        B(bc(2),bc(1)) = 1;
        B = bwdist(B);
%         x2(S./(1+B))

%         [subs,vals] = nonMaxSupr( double(S), 10, .1, 1);
        
        
        
%         showSortedBoxes(I,curBoxes,boxScores);
        
        aa = polyarea2(boxPolys{1});
        intAreas = intAreas/aa;        
        showPredsHelper2(fra_db,imdb,t);
        figure(4); 
        for u = 1:8
            vl_tightsubplot(2,4,u)
            plotPolygons(faceAndHandPolygon,'g-','LineWidth',2);
        end
        dpc
        %     action_object_regions{t} = maskedPatch(I,curMask,true);
        %
        %           clf; imagesc2(I);
        % %         plotBoxes(hand_boxes(t,:),'r-','LineWidth',2);
        % %         plotBoxes(face_boxes(t,:),'g-','LineWidth',2);
        %         plotBoxes(fra_db(t).I_rect,'m--','LineWidth',2);
        %         plotPolygons(faceAndHandPolygon,'c-','LineWidth',2);
        
        
        %         dpc
        % find the best action object inside this region :-)
        
        %     end
    end
end
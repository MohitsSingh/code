function [sel] = suppressLines(lines)
%SUPPRESSLINES Summary of this function goes here
%   Detailed explanation goes here
    % get the bounding boxes of the lines.
    

end


%%%%annotateParts

initpath;
config;

[train_ids,train_labels,all_train_labels] = getImageSet(conf,'train');

% 

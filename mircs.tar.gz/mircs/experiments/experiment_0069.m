% %%%% Experiment 0069 - fine tune imagenet on cifar :-)
% if (0)
%     initpath;
%     config;
%     addpath(genpath('~/code/3rdparty/matconvnet-1.0-beta11_gpu/'));
%     vl_setupnn;
% end


function [net, info] = cnn_cifar(varargin)
% CNN_CIFAR   Demonstrates MatConvNet on CIFAR-10
%    The demo includes two standard model: LeNet and Network in
%    Network (NIN). Use the 'modelType' option to choose one.

opts.modelType = 'lenet' ;
[opts, varargin] = vl_argparse(opts, varargin) ;

switch opts.modelType
    case 'lenet'
        opts.train.learningRate = [0.01*ones(1,7) 0.001*ones(1,10) 0.0005*ones(1,5)] ;
        opts.train.weightDecay = 0.0001 ;
    case 'nin'
        opts.train.learningRate = [0.5*ones(1,30) 0.1*ones(1,10) 0.02*ones(1,10)] ;
        opts.train.weightDecay = 0.0005 ;
    otherwise
        error('Unknown model type %s', opts.modelType) ;
end
opts.expDir = fullfile('~/storage/cnn_data', sprintf('cifar-%s', opts.modelType)) ;
[opts, varargin] = vl_argparse(opts, varargin) ;

opts.train.numEpochs = numel(opts.train.learningRate) ;
[opts, varargin] = vl_argparse(opts, varargin) ;

opts.dataDir = '/home/amirro/storage/matconv_data/data/cifar';
opts.imdbPath = fullfile(opts.expDir, 'imdb.mat');
opts.whitenData = true ;
opts.contrastNormalization = true ;
opts.train.batchSize = 100 ;
opts.train.continue = true ;
opts.train.gpus = [] ;
opts.train.expDir = opts.expDir ;
opts = vl_argparse(opts, varargin) ;

% --------------------------------------------------------------------
%                                               Prepare data and model
% --------------------------------------------------------------------


% L = load('~/storage/matconv_data/imagenet-vgg-f.mat');
% imdb.my_mean_image = L.normalization.averageImage;
% imdb.sz = size2(imdb.my_mean_image);

% switch opts.modelType
%     case 'lenet', net = cnn_cifar_init(opts) ;
%     case 'nin',   net = cnn_cifar_init_nin(opts) ;
% end

% imdb = getCifarImdb(opts) ;

% opts.imdbPath = '~/storage/cnn_data/cifar-lenet/imdb_small.mat';
% imdb = load(opts.imdbPath) ;

if exist(opts.imdbPath, 'file')
  imdb = load(opts.imdbPath) ;
else
  imdb = getCifarImdb(opts) ;
  mkdir(opts.expDir) ;
  save(opts.imdbPath, '-struct', 'imdb') ;
end



L = load('~/storage/matconv_data/imagenet-vgg-m.mat');
L.layers{1}.stride = [1 1];
L.layers{5}.stride = [1 1];
nFCNodes = 64;
 % make the fc6 filters 2x2
 
for u = 1:15
    if strcmp(L.layers{u}.type,'conv')
        L.layers{u}.learningRate = zeros(1, 2, 'single');
    end
end
sz = size(L.layers{16}.filters(3:4,3:4,1:nFCNodes,:));
L.layers{16} = struct('type', 'conv', 'name', 'fc6', ...
                           'weights', {{0.01 * randn(sz, 'single'), []}}, ...
                           'stride', [1 1], ...
                           'pad', [0 0 0 0], ...
                           'learningRate', [1 2], ...
                           'weightDecay', [1 0]) ;

% L.layers{16}.filters = L.layers{16}.filters(3:4,3:4,:,1:nFCNodes);

sz = size(L.layers{18}.filters(:,:,1:nFCNodes,:));
L.layers{18} = struct('type', 'conv', 'name', 'fc7', ...
                           'weights', {{0.01 * randn(sz, 'single'), []}}, ...
                           'stride', [1 1], ...
                           'pad', [0 0 0 0], ...
                           'learningRate', [1 2], ...
                           'weightDecay', [1 0]) ;

sz = size(L.layers{20}.filters(:,:,:,1:10));
L.layers{20} = struct('type', 'conv', 'name', 'fc8', ...
                           'weights', {{0.01 * randn(sz, 'single'), []}}, ...
                           'stride', [1 1], ...
                           'pad', [0 0 0 0], ...
                           'learningRate', [1 2], ...
                           'weightDecay', [1 0]) ;

% L.layers{20}.biases = L.layers{20}.biases(1:10);
L.layers{end} = struct('type', 'softmaxloss', 'name', 'loss') ;


[net, info] = cnn_train(L, imdb, @getBatch, ...
    opts.train, ...
    'val', find(imdb.images.set == 3),'gpus',1) ;

%L.layers{20}.filters
%r = vl_simplenn(L,single(zeros(32,32,3,1)));

% --------------------------------------------------------------------
function [im, labels] = getBatch(imdb, batch)
% --------------------------------------------------------------------
im = imdb.images.data(:,:,:,batch) ;

% im_new = zeros([imdb.sz 3 size(im,4)],'single');
% for t = 1:length(im)    
%     im_new(:,:,:,t) = imResample(im(:,:,:,t),imdb.sz);
% end
% %im = imResample(im,imdb.sz);
% im_new = bsxfun(@minus,im_new,imdb.my_mean_image);

labels = imdb.images.labels(1,batch) ;
%if rand > 0.5, im=fliplr(im) ; end
if rand > 0.5, im=flip_image(im) ; end

% --------------------------------------------------------------------
function imdb = getCifarImdb(opts)
% --------------------------------------------------------------------
% Preapre the imdb structure, returns image data with mean image subtracted
beADummy = 1;
% if beADummy
    


unpackPath = fullfile(opts.dataDir, 'cifar-10-batches-mat');
files = [arrayfun(@(n) sprintf('data_batch_%d.mat', n), 1:5, 'UniformOutput', false) ...
    {'test_batch.mat'}];
files = cellfun(@(fn) fullfile(unpackPath, fn), files, 'UniformOutput', false);
file_set = uint8([ones(1, 5), 3]);

if any(cellfun(@(fn) ~exist(fn, 'file'), files))
    url = 'http://www.cs.toronto.edu/~kriz/cifar-10-matlab.tar.gz' ;
    fprintf('downloading %s\n', url) ;
    untar(url, opts.dataDir) ;
end

data = cell(1, numel(files));
labels = cell(1, numel(files));
sets = cell(1, numel(files));
for fi = 1:numel(files)
    fd = load(files{fi}) ;
    data{fi} = permute(reshape(fd.data',32,32,3,[]),[2 1 3 4]) ;
    labels{fi} = fd.labels' + 1; % Index from 1
    sets{fi} = repmat(file_set(fi), size(labels{fi}));
end

%  
set = cat(2, sets{:});
data = single(cat(4, data{:}));

L = load('~/storage/matconv_data/imagenet-vgg-f.mat');
my_mean_image = L.normalization.averageImage;
my_mean_image = imResample(my_mean_image,size2(data));
% sz = size2(my_mean_image);


% im_new = zeros([sz 3 size(data,4)],'single');
% for t = 1:length(data)    
%     im_new(:,:,:,t) = imResample(data(:,:,:,t),sz);
% end
%im = imResample(im,imdb.sz);
data = bsxfun(@minus,data,my_mean_image);



% don't remove the datamean, this will be done later. 
% dataMean = mean(data(:,:,:,set == 1), 4);
% data = bsxfun(@minus, data, dataMean);

% normalize by image mean and std as suggested in `An Analysis of
% Single-Layer Networks in Unsupervised Feature Learning` Adam
% Coates, Honglak Lee, Andrew Y. Ng
% 
% if opts.contrastNormalization
%     z = reshape(data,[],60000) ;
%     z = bsxfun(@minus, z, mean(z,1)) ;
%     n = std(z,0,1) ;
%     z = bsxfun(@times, z, mean(n) ./ max(n, 40)) ;
%     data = reshape(z, 32, 32, 3, []) ;
% end

% if opts.whitenData
%     z = reshape(data,[],60000) ;
%     W = z(:,set == 1)*z(:,set == 1)'/60000 ;
%     [V,D] = eig(W) ;
%     % the scale is selected to approximately preserve the norm of W
%     d2 = diag(D) ;
%     en = sqrt(mean(d2)) ;
%     z = V*diag(en./max(sqrt(d2), 10))*V'*z ;
%     data = reshape(z, 32, 32, 3, []) ;
% end

clNames = load(fullfile(unpackPath, 'batches.meta.mat'));

imdb.images.data = data ;
imdb.images.labels = single(cat(2, labels{:})) ;
imdb.images.set = set;
imdb.meta.sets = {'train', 'val', 'test'} ;
imdb.meta.classes = clNames.label_names;

% try the cfss face alignment...

cd /home/amirro/code/3rdparty/CVPR15-CFSS-master


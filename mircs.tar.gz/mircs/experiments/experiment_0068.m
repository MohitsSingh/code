%%%% Experiment 0068 -  depth!!!

% % initpath
% % % config

addpath('~/storage/data/nyu/');


%A = load('nyu_depth_v2_labeled');

x2(A.images(:,:,:,15));
x2(A.depths(:,:,15))
x2(A.instances(:,:,15))
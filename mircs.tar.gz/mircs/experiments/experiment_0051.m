%% Experiment 0051 - Nov. 18 2014
%% Run face detection + classification of 4 action classes on TUHOI

initpath;




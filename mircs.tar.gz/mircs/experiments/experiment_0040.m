%% Experiment 0040 %%%%%%
%% 8/6/2014
% learn collections of parts models : /home/amirro/code/3rdparty/bcp_release
